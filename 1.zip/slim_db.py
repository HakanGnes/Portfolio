"""
slim_db.py
============
api_football_data.db icindeki raw_json sutununu kaldirip dosyayi kucultur.

NEDEN: raw_json, API-Football'dan donen ham cevabin tamami. Ihtiyacimiz
olan zengin istatistikler (tackles/duels/passes/dribbles/shots) zaten
migrate_rich_stats.py ile ayri sutunlara cikarildi. raw_json 38 MB'lik
veritabaninin ~27 MB'ini kapliyor ve artik kullanilmiyor.

GITHUB ICIN ONEMLI: 38 MB'lik bir dosyayi her commit'te tasimak repoyu
gereksiz sisirir. Bu islemden sonra ~11 MB'a duser.

GUVENLIK: Once yedek alir (api_football_data_backup.db). Islem geri
alinamaz oldugu icin yedegi silmeden once yeni DB ile uygulamanin
calistigini dogrula.

KULLANIM:
    python slim_db.py
"""

import os
import shutil
import sqlite3

DB_PATH = "api_football_data.db"
BACKUP_PATH = "api_football_data_backup.db"


def size_mb(path):
    return os.path.getsize(path) / 1024 / 1024


def main():
    if not os.path.exists(DB_PATH):
        print(f"HATA: {DB_PATH} bulunamadi.")
        return

    cols = [r[1] for r in sqlite3.connect(DB_PATH).execute("PRAGMA table_info(players)")]
    if "raw_json" not in cols:
        print("raw_json sutunu zaten yok - yapilacak bir sey yok.")
        print(f"Mevcut boyut: {size_mb(DB_PATH):.1f} MB")
        return

    before = size_mb(DB_PATH)
    print(f"Mevcut boyut: {before:.1f} MB")

    if not os.path.exists(BACKUP_PATH):
        print(f"Yedek aliniyor -> {BACKUP_PATH}")
        shutil.copy2(DB_PATH, BACKUP_PATH)
    else:
        print(f"Yedek zaten var: {BACKUP_PATH}")

    conn = sqlite3.connect(DB_PATH)
    print("raw_json sutunu kaldiriliyor...")
    conn.execute("ALTER TABLE players DROP COLUMN raw_json")
    conn.commit()

    print("Veritabani sikistiriliyor (VACUUM)...")
    conn.execute("VACUUM")
    conn.close()

    after = size_mb(DB_PATH)
    print(f"\nTamamlandi: {before:.1f} MB -> {after:.1f} MB "
          f"(%{(1 - after / before) * 100:.0f} kucuktu)")
    print(f"\nYedek: {BACKUP_PATH}")
    print("Uygulamanin calistigini dogruladiktan sonra yedegi silebilirsin.")
    print("(Yedek .gitignore'da, GitHub'a gitmez.)")


if __name__ == "__main__":
    main()
